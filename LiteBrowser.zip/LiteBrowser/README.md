# Lite Browser (Android)

A small, fast, private Android browser:
- Blocks ads and trackers (host list in AdBlocker.kt)
- Data saver: block images, block JavaScript, aggressive caching
- Optional compression proxy (server/ folder) like Opera Mini
- DuckDuckGo search, Do-Not-Track, no third-party cookies
- Can be set as the default browser

## Build the APK (free)
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > select the LiteBrowser folder. Wait for Gradle sync (needs internet the first time).
3. Plug in your phone (USB debugging on) and press Run, OR
   Build > Build Bundle(s) / APK(s) > Build APK(s). Copy app-debug.apk to your phone and install it.
4. Optional icon: right-click app/src/main/res > New > Image Asset.

## Run the compression proxy (optional)
    cd server
    npm install
    npm start
In the app: menu ⋮ > Set proxy server address (e.g. http://YOUR-SERVER-IP:8080), then turn on "Use compression proxy server".
The proxy can read pages you open, even HTTPS ones. Use it only with a server you control, and keep it off for banking and logins.

## Notes
- Not tested on a device yet: first build may need small fixes.
- No tabs, downloads or bookmarks yet.
