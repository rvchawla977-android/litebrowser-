package com.ravi.litebrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayInputStream
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("lite", MODE_PRIVATE) }

    // key, menu label, default value
    private val toggles = listOf(
        Triple("adblock", "Block ads & trackers", true),
        Triple("noimg", "Data saver: no images", false),
        Triple("nojs", "Block JavaScript (faster, lighter)", false),
        Triple("proxy", "Use compression proxy server", false)
    )

    private val home = "https://duckduckgo.com"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)
        applyPrefs()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                if (prefs.getBoolean("adblock", true) && AdBlocker.isBlocked(request.url.host)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!urlBar.hasFocus()) urlBar.setText(realUrl(url))
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
            }
        }

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                go(urlBar.text.toString())
                urlBar.clearFocus()
                true
            } else false
        }

        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        findViewById<View>(R.id.btnBack).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.btnForward).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.btnReload).setOnClickListener { web.reload() }
        findViewById<View>(R.id.btnHome).setOnClickListener { load(home) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (savedInstanceState == null) load(intent?.data?.toString() ?: home)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.toString()?.let { load(it) }
    }

    private fun proxyBase(): String = prefs.getString("proxy_url", "")!!.trimEnd('/')

    private fun realUrl(url: String): String {
        val base = proxyBase()
        return if (base.isNotEmpty() && url.startsWith("$base/p?"))
            Uri.parse(url).getQueryParameter("u") ?: url
        else url
    }

    private fun go(input: String) {
        val raw = input.trim()
        if (raw.isEmpty()) return
        val url = when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            !raw.contains(" ") && raw.contains(".") -> "https://$raw"
            else -> "https://duckduckgo.com/?q=" + URLEncoder.encode(raw, "UTF-8")
        }
        load(url)
    }

    private fun load(url: String) {
        val base = proxyBase()
        val target = if (prefs.getBoolean("proxy", false) && base.isNotEmpty())
            "$base/p?u=" + URLEncoder.encode(url, "UTF-8")
        else url
        // Do-Not-Track and Global Privacy Control headers
        web.loadUrl(target, mapOf("DNT" to "1", "Sec-GPC" to "1"))
    }

    private fun applyPrefs() {
        val noImg = prefs.getBoolean("noimg", false)
        web.settings.blockNetworkImage = noImg
        web.settings.javaScriptEnabled = !prefs.getBoolean("nojs", false)
        web.settings.cacheMode =
            if (noImg) WebSettings.LOAD_CACHE_ELSE_NETWORK else WebSettings.LOAD_DEFAULT
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        toggles.forEachIndexed { i, (key, label, def) ->
            pm.menu.add(0, i, i, label).apply {
                isCheckable = true
                isChecked = prefs.getBoolean(key, def)
            }
        }
        pm.menu.add(0, 100, 100, "Set proxy server address…")
        pm.menu.add(0, 101, 101, "Clear cookies, cache & history")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                100 -> askProxyUrl()
                101 -> clearData()
                else -> {
                    val (key, _, def) = toggles[item.itemId]
                    prefs.edit().putBoolean(key, !prefs.getBoolean(key, def)).apply()
                    applyPrefs()
                    web.reload()
                }
            }
            true
        }
        pm.show()
    }

    private fun askProxyUrl() {
        val input = EditText(this).apply {
            setText(prefs.getString("proxy_url", ""))
            hint = "http://your-server:8080"
        }
        AlertDialog.Builder(this)
            .setTitle("Proxy server address")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("proxy_url", input.text.toString().trim()).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearData() {
        web.clearCache(true)
        web.clearHistory()
        WebStorage.getInstance().deleteAllData()
        CookieManager.getInstance().removeAllCookies(null)
        Toast.makeText(this, "Cleared", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
