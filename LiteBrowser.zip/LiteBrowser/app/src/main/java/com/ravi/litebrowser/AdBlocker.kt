package com.ravi.litebrowser

/** Simple host-based ad/tracker blocker. Add more domains to the list as needed. */
object AdBlocker {
    private val blocked = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com",
        "adservice.google.com", "adnxs.com", "adsrvr.org", "adform.net",
        "amazon-adsystem.com", "taboola.com", "outbrain.com", "criteo.com",
        "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net",
        "casalemedia.com", "moatads.com", "scorecardresearch.com", "quantserve.com",
        "chartbeat.com", "hotjar.com", "mixpanel.com", "segment.io",
        "facebook.net", "connect.facebook.net", "ads-twitter.com", "analytics.twitter.com",
        "ads.linkedin.com", "snap.licdn.com", "bat.bing.com", "clarity.ms",
        "popads.net", "propellerads.com", "adsterra.com", "mgid.com",
        "revcontent.com", "zedo.com", "smartadserver.com", "advertising.com",
        "yieldmo.com", "media.net", "inmobi.com", "applovin.com",
        "unity3d.com", "adcolony.com", "vungle.com", "chartboost.com"
    )

    fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        var h = host.lowercase()
        while (true) {
            if (h in blocked) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
        }
    }
}
