// Lite compression proxy: shrinks pages and images before they reach the phone.
// Run:  npm install && npm start     (needs Node 18+)
const http = require('http');
const zlib = require('zlib');
const dns = require('dns').promises;
const net = require('net');
const sharp = require('sharp');
const cheerio = require('cheerio');

const PORT = process.env.PORT || 8080;
const IMG_WIDTH = 480;   // max image width sent to phone
const IMG_QUALITY = 35;  // WebP quality (lower = smaller)

function isPrivateIp(ip) {
  if (net.isIPv6(ip)) return ip === '::1' || ip.startsWith('fc') || ip.startsWith('fd') || ip.startsWith('fe80');
  const [a, b] = ip.split('.').map(Number);
  return a === 10 || a === 127 || a === 0 || (a === 172 && b >= 16 && b <= 31) ||
         (a === 192 && b === 168) || (a === 169 && b === 254);
}

// Block requests to internal networks (stops people abusing your server)
async function safeTarget(target) {
  if (!/^https?:\/\//i.test(target)) return false;
  const { hostname } = new URL(target);
  const addrs = await dns.lookup(hostname, { all: true });
  return addrs.length > 0 && addrs.every(a => !isPrivateIp(a.address));
}

function abs(base, href) {
  try { return new URL(href, base).href; } catch { return null; }
}
const prox = (url) => '/p?u=' + encodeURIComponent(url);
const imgProx = (url) => '/img?u=' + encodeURIComponent(url);

function send(req, res, status, type, body) {
  const headers = { 'Content-Type': type };
  if (/text|json|javascript|xml|css/.test(type) && /gzip/.test(req.headers['accept-encoding'] || '')) {
    body = zlib.gzipSync(body);
    headers['Content-Encoding'] = 'gzip';
  }
  res.writeHead(status, headers);
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    const target = u.searchParams.get('u');
    if (!target) return send(req, res, 400, 'text/plain', Buffer.from('Use /p?u=https://example.com'));
    if (!(await safeTarget(target))) return send(req, res, 403, 'text/plain', Buffer.from('Blocked target'));

    const r = await fetch(target, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Mobile) LiteProxy' },
      redirect: 'follow',
      signal: AbortSignal.timeout(15000)
    });
    const type = r.headers.get('content-type') || 'application/octet-stream';
    const buf = Buffer.from(await r.arrayBuffer());

    if (u.pathname === '/img') {
      const out = await sharp(buf).resize({ width: IMG_WIDTH, withoutEnlargement: true })
        .webp({ quality: IMG_QUALITY }).toBuffer();
      res.writeHead(200, { 'Content-Type': 'image/webp', 'Cache-Control': 'public, max-age=86400' });
      return res.end(out);
    }

    if (type.includes('text/html')) {
      const finalUrl = r.url || target;
      const $ = cheerio.load(buf.toString('utf8'));
      $('script, iframe, object, embed').remove();
      $('a[href]').each((_, el) => {
        const h = abs(finalUrl, $(el).attr('href'));
        if (h && /^https?:/i.test(h)) $(el).attr('href', prox(h));
      });
      $('img').each((_, el) => {
        const s = abs(finalUrl, $(el).attr('src') || $(el).attr('data-src'));
        $(el).removeAttr('srcset').removeAttr('data-src');
        if (s && /^https?:/i.test(s)) $(el).attr('src', imgProx(s)).attr('loading', 'lazy');
      });
      $('link[rel="stylesheet"]').each((_, el) => {
        const h = abs(finalUrl, $(el).attr('href'));
        if (h) $(el).attr('href', prox(h));
      });
      $('head').prepend('<meta name="viewport" content="width=device-width, initial-scale=1">');
      return send(req, res, 200, 'text/html; charset=utf-8', Buffer.from($.html()));
    }

    // everything else (CSS, etc.) passes through
    send(req, res, r.status, type, buf);
  } catch (e) {
    send(req, res, 502, 'text/plain', Buffer.from('Proxy error: ' + e.message));
  }
});

server.listen(PORT, () => console.log('Lite proxy running on port ' + PORT));
